package model;

/**
 * 
 * @author Erik Bollinger
 *
 */
public enum Gender {
	MALE,
	FEMALE
}
